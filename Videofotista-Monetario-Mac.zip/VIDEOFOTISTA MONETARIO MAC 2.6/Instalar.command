#!/bin/bash
# Clique duplo para instalar o Videofotista Monetário
cd "$(dirname "$0")"
bash ./instalar.sh
echo ""
echo "Pode fechar esta janela."
