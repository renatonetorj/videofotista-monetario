#!/bin/bash
# Instala o Videofotista Monetário em Aplicativos
set -e
cd "$(dirname "$0")"
NOME="Videofotista Monetário"
APP="/Applications/$NOME.app"
echo ""
echo "Instalando o $NOME..."
if ! xcode-select -p >/dev/null 2>&1; then
  echo ""
  echo "Falta um componente da Apple (Ferramentas de Linha de Comando)."
  echo "Vai abrir uma janela: clique em Instalar. Quando terminar, rode este instalador de novo."
  xcode-select --install || true
  exit 1
fi
TMP="$(mktemp -d)"
echo "Montando o app..."
swiftc -O fonte/main.swift -o "$TMP/Monetario" -framework Cocoa -framework WebKit -framework Network
osascript -e "quit app \"$NOME\"" >/dev/null 2>&1 || true
sleep 1
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/web"
cp "$TMP/Monetario" "$APP/Contents/MacOS/Monetario"
cp fonte/web/* "$APP/Contents/Resources/web/"
echo "Fazendo o ícone..."
mkdir -p "$TMP/icone.iconset"
for s in 16 32 128 256 512; do
  sips -z $s $s fonte/web/icone.png --out "$TMP/icone.iconset/icon_${s}x${s}.png" >/dev/null
  d=$((s*2))
  sips -z $d $d fonte/web/icone.png --out "$TMP/icone.iconset/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$TMP/icone.iconset" -o "$APP/Contents/Resources/icone.icns"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>$NOME</string>
  <key>CFBundleDisplayName</key><string>$NOME</string>
  <key>CFBundleIdentifier</key><string>br.com.renatoneto.monetario</string>
  <key>CFBundleExecutable</key><string>Monetario</string>
  <key>CFBundleIconFile</key><string>icone</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>2.0</string>
  <key>CFBundleVersion</key><string>2.0</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSHumanReadableCopyright</key><string>Renato Neto, O Videofotista</string>
  <key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/></dict>
</dict>
</plist>
PLIST
xattr -cr "$APP" 2>/dev/null || true
codesign --force --deep -s - "$APP" >/dev/null 2>&1 || true
touch "$APP"
rm -rf "$TMP"
echo "Abrindo..."
open "$APP"
echo ""
echo "Pronto! O $NOME está em Aplicativos."
echo "Para deixar no Dock: com o app aberto, clique com o botão direito no ícone dele no Dock > Opções > Manter no Dock."
