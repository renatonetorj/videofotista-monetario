import Cocoa
import WebKit
import Network

let NOME_APP = "Videofotista Monetário"
let PORTA: UInt16 = 47821
let DIAS_DE_BACKUP = 90

// Servidor local mínimo: entrega os arquivos do app em http://127.0.0.1:PORTA
final class ServidorLocal {
    let pasta: URL
    var listener: NWListener?
    init(pasta: URL) { self.pasta = pasta }

    func iniciar(pronto: @escaping (Bool) -> Void) {
        do {
            let params = NWParameters.tcp
            params.requiredLocalEndpoint = NWEndpoint.hostPort(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: PORTA)!)
            params.allowLocalEndpointReuse = true
            let l = try NWListener(using: params)
            l.newConnectionHandler = { [weak self] c in self?.atender(c) }
            var avisou = false
            l.stateUpdateHandler = { estado in
                switch estado {
                case .ready: if !avisou { avisou = true; DispatchQueue.main.async { pronto(true) } }
                case .failed(_): if !avisou { avisou = true; DispatchQueue.main.async { pronto(false) } }
                default: break
                }
            }
            l.start(queue: .global(qos: .userInitiated))
            listener = l
        } catch {
            pronto(false)
        }
    }

    func tipo(_ ext: String) -> String {
        switch ext.lowercased() {
        case "html": return "text/html; charset=utf-8"
        case "js": return "application/javascript; charset=utf-8"
        case "json": return "application/json; charset=utf-8"
        case "png": return "image/png"
        case "css": return "text/css; charset=utf-8"
        case "svg": return "image/svg+xml"
        default: return "application/octet-stream"
        }
    }

    func atender(_ c: NWConnection) {
        c.start(queue: .global(qos: .userInitiated))
        c.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] dados, _, _, _ in
            guard let self = self, let dados = dados, let texto = String(data: dados, encoding: .utf8) else { c.cancel(); return }
            let linha = texto.components(separatedBy: "\r\n").first ?? ""
            let partes = linha.split(separator: " ")
            var caminho = partes.count > 1 ? String(partes[1]) : "/"
            if let q = caminho.firstIndex(of: "?") { caminho = String(caminho[..<q]) }
            caminho = caminho.removingPercentEncoding ?? caminho
            if caminho == "/" || caminho.isEmpty { caminho = "/index.html" }
            let rel = caminho.split(separator: "/").filter { $0 != ".." && $0 != "." }.joined(separator: "/")
            let arq = self.pasta.appendingPathComponent(rel)
            var corpo = Data()
            var status = "200 OK"
            var ctype = self.tipo(arq.pathExtension)
            if let d = try? Data(contentsOf: arq) { corpo = d } else { status = "404 Not Found"; corpo = Data("nao encontrado".utf8); ctype = "text/plain" }
            let cab = "HTTP/1.1 \(status)\r\nContent-Type: \(ctype)\r\nContent-Length: \(corpo.count)\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n"
            if partes.first == "HEAD" { corpo = Data() }
            var resposta = Data(cab.utf8); resposta.append(corpo)
            c.send(content: resposta, completion: .contentProcessed { _ in c.cancel() })
        }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    var window: NSWindow!
    var webView: WKWebView!
    var servidor: ServidorLocal!
    let fm = FileManager.default

    lazy var pastaBackups: URL = {
        let u = fm.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("\(NOME_APP) - Backups", isDirectory: true)
        try? fm.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }()

    // Google Drive para computador: ~/Library/CloudStorage/GoogleDrive-<conta>/Meu Drive (ou My Drive)
    var pastaDrive: URL? {
        let cs = fm.homeDirectoryForCurrentUser.appendingPathComponent("Library/CloudStorage", isDirectory: true)
        guard let itens = try? fm.contentsOfDirectory(at: cs, includingPropertiesForKeys: nil) else { return nil }
        for g in itens where g.lastPathComponent.hasPrefix("GoogleDrive") {
            for nome in ["Meu Drive", "My Drive"] {
                let m = g.appendingPathComponent(nome, isDirectory: true)
                var dir: ObjCBool = false
                if fm.fileExists(atPath: m.path, isDirectory: &dir), dir.boolValue {
                    let alvo = m.appendingPathComponent("\(NOME_APP) - Backups", isDirectory: true)
                    try? fm.createDirectory(at: alvo, withIntermediateDirectories: true)
                    return alvo
                }
            }
        }
        return nil
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        montarMenu()
        montarJanela()
        let web = Bundle.main.resourceURL!.appendingPathComponent("web", isDirectory: true)
        servidor = ServidorLocal(pasta: web)
        servidor.iniciar { [weak self] ok in
            guard let self = self else { return }
            if ok { self.carregar() } else { self.mostrarErro() }
        }
        NSApp.activate(ignoringOtherApps: true)
    }

    func carregar() {
        webView.load(URLRequest(url: URL(string: "http://127.0.0.1:\(PORTA)/index.html")!))
    }

    func mostrarErro() {
        let html = "<html><body style='background:#737373;color:#fff;font-family:-apple-system;padding:40px'><h2>Não consegui abrir o Monetário</h2><p>Talvez ele já esteja aberto em outra janela. Feche o app (Cmd+Q) e abra de novo.</p></body></html>"
        webView.loadHTMLString(html, baseURL: nil)
    }

    func montarJanela() {
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = WKWebsiteDataStore.default()
        let ucc = WKUserContentController()
        ucc.add(self, name: "salvar")
        ucc.add(self, name: "backup")
        cfg.userContentController = ucc
        cfg.preferences.javaScriptCanOpenWindowsAutomatically = true

        webView = WKWebView(frame: .zero, configuration: cfg)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.setValue(false, forKey: "drawsBackground")
        if #available(macOS 13.3, *) { webView.isInspectable = true }

        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1100, height: 820),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = NOME_APP
        window.backgroundColor = NSColor(calibratedRed: 0.451, green: 0.451, blue: 0.451, alpha: 1)
        window.minSize = NSSize(width: 380, height: 500)
        window.contentView = webView
        window.delegate = self
        window.center()
        window.setFrameAutosaveName("JanelaMonetario")
        window.isReleasedWhenClosed = false
        window.makeKeyAndOrderFront(nil)
    }

    func montarMenu() {
        let principal = NSMenu()
        let itemApp = NSMenuItem(); principal.addItem(itemApp)
        let menuApp = NSMenu()
        menuApp.addItem(withTitle: "Sobre o \(NOME_APP)", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        menuApp.addItem(.separator())
        menuApp.addItem(withTitle: "Abrir pasta de backups", action: #selector(abrirBackups), keyEquivalent: "")
        menuApp.addItem(.separator())
        menuApp.addItem(withTitle: "Ocultar", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        menuApp.addItem(withTitle: "Sair do \(NOME_APP)", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        itemApp.submenu = menuApp

        let itemEd = NSMenuItem(); principal.addItem(itemEd)
        let menuEd = NSMenu(title: "Editar")
        menuEd.addItem(withTitle: "Desfazer", action: Selector(("undo:")), keyEquivalent: "z")
        menuEd.addItem(withTitle: "Refazer", action: Selector(("redo:")), keyEquivalent: "Z")
        menuEd.addItem(.separator())
        menuEd.addItem(withTitle: "Recortar", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        menuEd.addItem(withTitle: "Copiar", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        menuEd.addItem(withTitle: "Colar", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        menuEd.addItem(withTitle: "Selecionar Tudo", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        itemEd.submenu = menuEd

        let itemVer = NSMenuItem(); principal.addItem(itemVer)
        let menuVer = NSMenu(title: "Visualizar")
        menuVer.addItem(withTitle: "Recarregar", action: #selector(recarregar), keyEquivalent: "r")
        menuVer.addItem(withTitle: "Aumentar texto", action: #selector(zoomMais), keyEquivalent: "+")
        menuVer.addItem(withTitle: "Diminuir texto", action: #selector(zoomMenos), keyEquivalent: "-")
        menuVer.addItem(withTitle: "Tamanho normal", action: #selector(zoomNormal), keyEquivalent: "0")
        itemVer.submenu = menuVer

        let itemJan = NSMenuItem(); principal.addItem(itemJan)
        let menuJan = NSMenu(title: "Janela")
        menuJan.addItem(withTitle: "Minimizar", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        menuJan.addItem(withTitle: "Fechar", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        itemJan.submenu = menuJan
        NSApp.windowsMenu = menuJan
        NSApp.mainMenu = principal
    }

    @objc func recarregar() { webView.reload() }
    @objc func zoomMais() { webView.pageZoom = min(webView.pageZoom + 0.1, 2.0) }
    @objc func zoomMenos() { webView.pageZoom = max(webView.pageZoom - 0.1, 0.6) }
    @objc func zoomNormal() { webView.pageZoom = 1.0 }
    @objc func abrirBackups() { NSWorkspace.shared.open(pastaBackups) }

    // Reabrir a janela ao clicar no ícone do Dock
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag { window.makeKeyAndOrderFront(nil) }
        return true
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }

    // Mensagens do app (JavaScript)
    func userContentController(_ uc: WKUserContentController, didReceive msg: WKScriptMessage) {
        guard let corpo = msg.body as? [String: Any] else { return }
        if msg.name == "salvar", let nome = corpo["nome"] as? String, let b64 = corpo["b64"] as? String,
           let dados = Data(base64Encoded: b64) {
            let downloads = fm.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
            var destino = downloads.appendingPathComponent(limpo(nome))
            var n = 2
            while fm.fileExists(atPath: destino.path) {
                let base = (limpo(nome) as NSString).deletingPathExtension, ext = (nome as NSString).pathExtension
                destino = downloads.appendingPathComponent("\(base) (\(n)).\(ext)"); n += 1
            }
            do { try dados.write(to: destino); NSWorkspace.shared.activateFileViewerSelecting([destino]) } catch { NSSound.beep() }
        }
        if msg.name == "backup", let nome = corpo["nome"] as? String, let texto = corpo["texto"] as? String {
            let dados = Data(texto.utf8)
            for pasta in [pastaBackups, pastaDrive].compactMap({ $0 }) {
                try? dados.write(to: pasta.appendingPathComponent(limpo(nome)))
                podar(pasta)
            }
        }
    }

    func limpo(_ s: String) -> String {
        s.replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
    }

    func podar(_ pasta: URL) {
        guard let itens = try? fm.contentsOfDirectory(at: pasta, includingPropertiesForKeys: nil) else { return }
        let bks = itens.filter { $0.lastPathComponent.hasPrefix("MONETARIO_backup_") }.sorted { $0.lastPathComponent > $1.lastPathComponent }
        if bks.count > DIAS_DE_BACKUP { for u in bks[DIAS_DE_BACKUP...] { try? fm.removeItem(at: u) } }
    }

    // Escolher arquivo (Importar backup)
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let p = NSOpenPanel()
        p.canChooseFiles = true
        p.canChooseDirectories = false
        p.allowsMultipleSelection = parameters.allowsMultipleSelection
        p.directoryURL = pastaBackups
        p.beginSheetModal(for: window) { r in completionHandler(r == .OK ? p.urls : nil) }
    }

    // Links externos abrem no navegador
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = action.request.url, let host = url.host, host != "127.0.0.1",
           action.navigationType == .linkActivated || action.targetFrame == nil {
            NSWorkspace.shared.open(url); decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url { NSWorkspace.shared.open(url) }
        return nil
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = NSAlert(); a.messageText = message; a.runModal(); completionHandler()
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = NSAlert(); a.messageText = message; a.addButton(withTitle: "OK"); a.addButton(withTitle: "Cancelar")
        completionHandler(a.runModal() == .alertFirstButtonReturn)
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { carregar() }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
